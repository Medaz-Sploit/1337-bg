/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/04 22:29:39 by mazoukni          #+#    #+#             */
/*   Updated: 2021/10/04 22:37:31 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char **argv)
{
	t_data	*data;

	data = malloc(sizeof(t_data));
	init(data);
	check_isdigit(argv, &data);
	data->stack_a = conv_tab_tolinkedlist(argv, argc, &data);
	is_duplicate(data->stack_a, &data);
	if (argc == 1 || is_sorted(data->stack_a))
		return (clear_all(&data));
	if (lent_stack(data->stack_a) == 2)
		exec_save_inst("sa", data);
	else if (lent_stack(data->stack_a) == 3)
		sort_three_numbers(data);
	else if (lent_stack(data->stack_a) == 4)
		sort_four_num(data);
	else if (lent_stack(data->stack_a) == 5)
		sort_five_num(data);
	else if (lent_stack(data->stack_a) > 5)
		sortmorethanfive(data);
	printlist_cmds(data->cmd_list);
	clear_all(&data);
	return (0);
}
