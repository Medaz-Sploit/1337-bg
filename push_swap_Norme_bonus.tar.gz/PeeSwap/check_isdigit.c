/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_functions3.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/04 22:29:22 by mazoukni          #+#    #+#             */
/*   Updated: 2021/10/04 22:37:14 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	help(char *str)
{
	int		i;

	i = 0;
	if ((str[0] == '-' || str[0] == '+') && str[1] == '\0')
		return (0);
	if (str[0] == '-' || str[0] == '+')
		str++;
	while (str[i])
	{
		if (ft_isdigit(str[i]) == 0)
			return (0);
		i++;
	}
	return (1);
}

void	check_isdigit(char **tab, t_data **data)
{
	int		i;

	i = 1;
	while (tab[i])
	{
		if (help(tab[i]) == 0)
			ft_puterror("ERRROR!\n", data);
		i++;
	}
}

void	*ft_calloc(size_t count, size_t size)
{
	char	*p;
	long	i;

	i = count * size;
	p = malloc(i);
	if (!p)
		return (0);
	while (i--)
		p[i] = 0;
	return (p);
}
