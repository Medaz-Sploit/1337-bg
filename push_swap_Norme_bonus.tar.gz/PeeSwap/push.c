/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/04 22:29:47 by mazoukni          #+#    #+#             */
/*   Updated: 2021/10/04 22:37:39 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	pa(t_data *data)
{
	t_node	*tmp;

	if (!data->stack_b)
		return ;
	tmp = data->stack_b;
	data->stack_b = (data->stack_b)->next;
	tmp->next = data->stack_a;
	data->stack_a = tmp;
}

void	pb(t_data *data)
{
	t_node	*tmp;

	if (!data->stack_a)
		return ;
	tmp = data->stack_a;
	data->stack_a = (data->stack_a)->next;
	tmp->next = data->stack_b;
	data->stack_b = tmp;
}

int	ret(char **str)
{
	free(*str);
	return (1);
}
