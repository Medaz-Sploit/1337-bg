#include "include/tocken.h"

tocken_T* init_tocken(int type, char* value)
{
	tocken_T* tocken = calloc(1, sizeof(struct TOCKEN_STRUCT));

	tocken->type = type;
	tocken->value = value;

	return (tocken);
}
