#ifndef TOCKEN_H
#define TOCKEN_H

#include <stdlib.h>

typedef struct TOCKEN_STRUCT
{
	enum
	{
		TOCKEN_ID,
		TOCKEN_EQUALS,
		TOCKEN_STRING,
		TOCKEN_PIP,
		TOCKEN_DOLLAR,
		TOCKEN_LREDIRECTION,
		TOCKEN_RREDIRECTION
	}	type;
	char *value;
}	tocken_T;

tocken_T* init_tocken(int type, char *value);

#endif
