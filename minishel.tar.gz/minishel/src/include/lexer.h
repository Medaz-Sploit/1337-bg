#ifndef LEXER_H
#define LEXER_H

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "tocken.h"

typedef struct LEXER_STRUCT
{
	char c;
	unsigned int i;
	char *contents;
}	lexer_T;

lexer_T* init_lexer(char *contents);

void lexer_advance(lexer_T* lexer);

void lexer_skip_whitespace(lexer_T* lexer);

tocken_T* lexer_get_next_tocken(lexer_T* lexer);

tocken_T* lexer_collect_string(lexer_T* lexer);

tocken_T* lexer_collect_id(lexer_T* lexer);

tocken_T* lexer_advance_with_tocken(lexer_T* lexer, tocken_T* tocken);

char* lexer_get_current_char_as_string(lexer_T* lexer);

#endif
