#include <stdio.h>
#include "include/lexer.h"

int main()
{

	lexer_T* lexer ;
	while ((lexer = init_lexer(readline("\x1B[31mLAIN_IS_LAIN@Medaz-Sploit.zone$> \x1B[37m"))))
	{
		tocken_T* tocken = (void*)0;
		
		while ((tocken = lexer_get_next_tocken(lexer)) != (void*)0)
		{
			printf("TOCKEN(%d, %s)\n", tocken->type, tocken->value);
		}
	}
	return (0);
}
