#include "include/lexer.h"

lexer_T* init_lexer(char* contents)
{
	lexer_T* lexer = calloc(1, sizeof(struct LEXER_STRUCT));
	lexer->contents = contents;
	lexer->i = 0;
	lexer->c = contents[lexer->i];

	return lexer;
}

void	lexer_advance(lexer_T* lexer)
{
	if (lexer->c != '\0' && lexer->i < strlen(lexer->contents))
	{
		lexer->i += 1;
		lexer->c = lexer->contents[lexer->i];
	}
}

void	lexer_skip_whitespace(lexer_T* lexer)
{
	while (lexer->c == ' ' || lexer->c == 10)
	{
		lexer_advance(lexer);
	}
}

tocken_T* lexer_get_next_tocken(lexer_T* lexer)
{
	while (lexer->c != '\0' && lexer->i < strlen(lexer->contents))
	{
		if (lexer->c == ' ' || lexer->c == 10)
			lexer_skip_whitespace(lexer);
		if (isalnum(lexer->c))
			return (lexer_collect_id(lexer));
		if (lexer->c == '"' || lexer->c == '\'')
			return (lexer_collect_string(lexer));
		switch (lexer->c)
		{
			case '=': return (lexer_advance_with_tocken(lexer, init_tocken(TOCKEN_EQUALS, lexer_get_current_char_as_string(lexer)))); break;	
			case '|': return (lexer_advance_with_tocken(lexer, init_tocken(TOCKEN_PIP, lexer_get_current_char_as_string(lexer)))); break;	
			case '$': return (lexer_advance_with_tocken(lexer, init_tocken(TOCKEN_DOLLAR, lexer_get_current_char_as_string(lexer)))); break;
			case '<': return (lexer_advance_with_tocken(lexer, init_tocken(TOCKEN_LREDIRECTION, lexer_get_current_char_as_string(lexer)))); break;
			case '>': return (lexer_advance_with_tocken(lexer, init_tocken(TOCKEN_RREDIRECTION, lexer_get_current_char_as_string(lexer)))); break;
		}
	}
	return ((void*)0);
}

tocken_T* lexer_advance_with_tocken(lexer_T* lexer, tocken_T* tocken)
{
	lexer_advance(lexer);

	return (tocken);
}

tocken_T* lexer_collect_string(lexer_T* lexer)
{
	char *value = calloc(1, sizeof(char));
	value[0] = '\0';

	lexer_advance(lexer);

	while (lexer->c != '"')
	{
		char *s = lexer_get_current_char_as_string(lexer);
		value = realloc(value, (strlen(value) + strlen(s) + 1) *sizeof(char));
		strcat(value, s);
		lexer_advance(lexer);
	}

	lexer_advance(lexer);

	return (init_tocken(TOCKEN_STRING, value));
}

tocken_T* lexer_collect_id(lexer_T* lexer)
{
	char *value = calloc(1, sizeof(char));
	value[0] = '\0';

	while (isalnum(lexer->c))
	{
		
		char *s = lexer_get_current_char_as_string(lexer);
		value = realloc(value, (strlen(value) + strlen(s) + 1) *sizeof(char));
		strcat(value, s);
		lexer_advance(lexer);
	}

	lexer_advance(lexer);
	return (init_tocken(TOCKEN_ID, value));
}

char* lexer_get_current_char_as_string(lexer_T* lexer)
{
	char *str = calloc(2, sizeof(char));
	str[0] = lexer->c;
	str[1] = '\0';

	return (str);
}












































