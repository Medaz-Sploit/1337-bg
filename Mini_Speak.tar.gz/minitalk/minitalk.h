/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minitalk.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/12 17:56:44 by mazoukni          #+#    #+#             */
/*   Updated: 2021/06/21 22:11:24 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINITALK_H
# define MINITALK_H

# include <stdlib.h>
# include <fcntl.h>
# include <unistd.h>
# include <signal.h>
# include <sys/types.h>
# include <strings.h>
# include <stdio.h>
# include <time.h>
# include <wchar.h>
# include "libft/libft.h"

typedef struct s_client
{
	char character;
	char *string;
	FILE *file_process;
}				t_client;

typedef struct	s_server
{
	pid_t pid;
}				t_server;

char	*ft_join_string(char *string, int character);
void	print_error(int error);


#endif