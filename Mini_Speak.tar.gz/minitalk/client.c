/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   client.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/12 17:56:30 by mazoukni          #+#    #+#             */
/*   Updated: 2021/07/09 19:40:12 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

/*
** The main goal of this project is to create a communication between processors using Two Signals called 
** SIGUSR1 and SIGUSR2 , we must create two programs client and server , the serevr must be launched first
** and after being launched it must display its PID
** the client will take as parameters [the server PID & the string that should be sent]
** the client must communicate the string passed as a parameter to the server, One the string has been received 
** the server must display it
** Your server should be able to recieve strings from several clients in a row, without needed to be restarted   
*/


