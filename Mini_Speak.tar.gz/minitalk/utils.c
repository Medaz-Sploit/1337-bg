/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/13 18:51:16 by mazoukni          #+#    #+#             */
/*   Updated: 2021/07/07 09:53:09 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minitalk.h"

void print_error(int error)
{
	if (error == 0)
		exit(0);
	else if (error == 1)
		printf("CHILD : \nProcess is a Child \uF476 ");
	else if (error == 2)
		printf("PARENT : \nSending SIGHUP \u2708");
	else if (error == 3)
		printf("PARENT : \nSending SIGINT");
	else if (error == 4)
		printf("PARENT : \nSending SIGQUIT");
	else if (error == 5)
		printf("MALLOC_ERROR : \n__FATAL_ERROR_MALLOC__");
	else if (error == 6)
		printf("PARENT : \n");
	else if (error == 7)
		printf("PARENT : \n");
}