/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_read.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/05 18:22:03 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 18:54:58 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	utils_buffer(char *line, int i)
{
	if (g_cub->id.r == 1 && g_cub->id.no == 1 && g_cub->id.so == 1 && \
g_cub->id.ea == 1 && g_cub->id.we == 1 && g_cub->id.s == 1 && \
g_cub->id.f == 1 && g_cub->id.c == 1)
	{
		buffer_map(g_cub, line);
		g_cub->id.m++;
		if (line[i] == '\0')
			exit_game(g_cub, 11);
		while (line[i])
		{
			if (line[i] != ' ' && line[i] != '2' && line[i] != '0' && \
line[i] != '1' && line[i] != 'N' && line[i] != 'S' && line[i] != 'E' && \
line[i] != 'W')
				exit_game(g_cub, 11);
			i++;
		}
	}
	else
		exit_game(g_cub, 12);
}

void	help_texture(char *line, int i)
{
	if (line[i] == 'N' && line[i + 1] == 'O')
	{
		if (g_cub->id.no >= 1)
			exit_game(g_cub, 14);
		g_cub->id.no++;
		g_cub->map.north = save_texture(line, i);
	}
	if (line[i] == 'S' && line[i + 1] == 'O')
	{
		if (g_cub->id.so >= 1)
			exit_game(g_cub, 15);
		g_cub->id.so++;
		g_cub->map.south = save_texture(line, i);
	}
	if (line[i] == 'E' && line[i + 1] == 'A')
	{
		if (g_cub->id.ea >= 1)
			exit_game(g_cub, 16);
		g_cub->id.ea++;
		g_cub->map.east = save_texture(line, i);
	}
}

void	utils_line(char *line, int i)
{
	if (line[i] == 'F' && line[i + 1] == ' ' )
	{
		if (g_cub->id.f >= 1)
			exit_game(g_cub, 19);
		g_cub->id.f++;
		g_cub->map.floor = save_color(g_cub, line, i);
	}
	if (line[i] == 'C' && line[i + 1] == ' ')
	{
		if (g_cub->id.c >= 1)
			exit_game(g_cub, 20);
		g_cub->id.c++;
		g_cub->map.ceiling = save_color(g_cub, line, i);
	}
}

void	Touch_Vert(void)
{
	while (g_cast.nextVertTouchX >= 0 && g_cast.nextVertTouchX < \
g_cub->map.width * TILE_SIZE && g_cast.nextVertTouchY >= 0 && \
g_cast.nextVertTouchY < g_cub->map.height * TILE_SIZE)
	{
		if (hasWallAt(g_cast.nextVertTouchX - (\
g_cub->isRayFacingLeft ? 1 : 0), g_cast.nextVertTouchY))
		{
			g_cast.foundVertWallHit = true;
			g_cast.vertWallHitX = g_cast.nextVertTouchX;
			g_cast.vertWallHitY = g_cast.nextVertTouchY;
			break ;
		}
		else
		{
			g_cast.nextVertTouchX += g_cast.xstep;
			g_cast.nextVertTouchY += g_cast.ystep;
		}
	}
}
