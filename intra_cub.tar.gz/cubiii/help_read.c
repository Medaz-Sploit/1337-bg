/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_read.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/05 03:29:18 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 13:42:29 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	read_fil(char **argv, t_cub *g_cub)
{
	int		fd;
	char	*line;

	fd = open(argv[1], O_RDONLY);
	if (fd < 1)
		exit_game(g_cub, 7);
	while (get_next_line(fd, &line))
	{
		read_lin(g_cub, line);
		free(line);
		line = NULL;
	}
	read_lin(g_cub, line);
	free(line);
	line = NULL;
	close(fd);
	check_file(g_cub);
	free_tab(g_cub->map.map);
	save_map(g_cub);
	check_map(g_cub);
	return (1);
}

size_t	ft_tablen(char **s)
{
	size_t	len;

	len = 0;
	if (s)
	{
		while (s[len] != NULL)
			len++;
	}
	return (len);
}

int	condition(char **map, int i, int j)
{
	if (map[i][j] == '0' || map[i][j] == 'N' || map[i][j] == 'S' || \
map[i][j] == 'E' || map[i][j] == 'W')
		if (map[i - 1][j] == '4' || map[i + 1][j] == '4' || \
map[i][j - 1] == '4' || map[i][j + 1] == '4')
			return (1);
	return (0);
}

void	help_save_color(char *line, int i)
{
	while (line[i])
	{
		if (line[i] == ',' || ft_isdigit(line[i]) || \
ft_issymbol(line[i]) || ft_isalpha(line[i]))
			exit_game(g_cub, 26);
		i++;
	}
}

void	util_sprite(int i, int len, char **tab)
{
	while (++i < len)
		if (!ft_isdigit(tab[1][i]))
			exit_game(g_cub, 23);
}
