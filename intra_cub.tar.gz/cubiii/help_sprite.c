/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_sprite.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/05 02:50:01 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 13:41:21 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	init_sprites_pos(void)
{
	int			i;
	int			j;
	int			k;

	i = 0;
	j = 0;
	k = 0;
	while (g_cub->map.map[i] != '\0' && k < g_cub->rc.nbr_sprites)
	{
		j = 0;
		while (g_cub->map.map[i][j] != '\0' && k < g_cub->rc.nbr_sprites)
		{
			if (g_cub->map.map[i][j] == '2')
			{
				g_s_data[k].coord_x = (i + 0.5) * TILE_SIZE;
				g_s_data[k].coord_y = (j + 0.5) * TILE_SIZE;
				k++;
			}
			j++;
		}
		i++;
	}
}

void	init_sprites(void)
{
	int			i;
	int			j;

	i = 0;
	j = 0;
	while (g_cub->map.map[i] != '\0')
	{
		j = 0;
		while (g_cub->map.map[i][j] != '\0')
		{
			if (g_cub->map.map[i][j] == '2')
				g_cub->rc.nbr_sprites += 1;
			j++;
		}
		i++;
	}
	if (g_cub->rc.nbr_sprites >= 50)
		exit_game(g_cub, 35);
	init_sprites_pos();
}

void	help_save(t_cub *g_cub, int i, int j, int k)
{
	while (g_cub->map.tmp[k])
	{
		if (g_cub->map.tmp[k] != '\n')
		{
			g_cub->map.map[i][j] = g_cub->map.tmp[k];
			j++;
		}
		else
		{
			g_cub->map.map[i][j] = '\0';
			i++;
			j = 0;
		}
		k++;
	}
}

int	help_color(char *line, int i, int color, int j)
{
	if (j >= 2)
		exit_game(g_cub, 26);
	check_color(g_cub, line, i);
	color += ft_atoi(&line[i]) * pow(2, 8);
	j = 0;
	while (ft_isdigit(line[i]))
		i++;
	while (line[i] == ',' || line[i] == ' ')
	{
		if (line[i] == ',')
			j++;
		i++;
	}
	if (j >= 2)
		exit_game(g_cub, 26);
	check_color(g_cub, line, i);
	color += ft_atoi(&line[i]);
	if (!ft_isdigit(line[i]))
		exit_game(g_cub, 26);
	while (ft_isdigit(line[i]))
		i++;
	help_save_color(line, i);
	return (color);
}

void	ressolution(int *x, int *y, char **tab)
{
	int	i;
	int	len;

	if (g_cub->id.r >= 1)
		exit_game(g_cub, 13);
	g_cub->id.r++;
	if (ft_strlen(tab[0]) != 1)
		exit_game(g_cub, 13);
	if (ft_tablen(tab) != 3)
		exit_game(g_cub, 23);
	len = ft_strlen(tab[1]);
	i = -1;
	util_sprite(i, len, tab);
	i = -1;
	len = ft_strlen(tab[2]);
	while (++i < len)
		if (!ft_isdigit(tab[2][i]))
			exit_game(g_cub, 23);
	*x = ft_atoi(tab[1]);
	*y = ft_atoi(tab[2]);
	if (*x > 2561 || *x < 0)
		*x = 2560;
	if (*y > 1440 || *y < 0)
		*y = 1440;
}
