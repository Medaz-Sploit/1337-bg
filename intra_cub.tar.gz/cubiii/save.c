/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   save.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/27 03:45:27 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 03:26:40 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

static void	help_alloc(t_cub *g_cub, int i, int j)
{
	while (g_cub->map.tmp[i])
	{
		if (g_cub->map.tmp[i] == '\n')
		{
			if (g_cub->map.columns < j)
				g_cub->map.columns = j - 1;
			j = 0;
		}
		i++;
		j++;
	}
}

static void	alloc_map(t_cub *g_cub)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	help_alloc(g_cub, i, j);
	g_cub->map.map = malloc(sizeof(char *) * (g_cub->map.rows + 1));
	if (!g_cub->map.map)
		exit_game(g_cub, 6);
	i = 0;
	while (i < g_cub->map.rows)
	{
		g_cub->map.map[i] = ft_calloc(sizeof(char), (g_cub->map.columns + 1));
		if (!g_cub->map.map[i])
			exit_game(g_cub, 6);
		i++;
	}
}

void	save_map(t_cub *g_cub)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	while (g_cub->map.tmp[i])
	{
		if (g_cub->map.tmp[i] == ' ')
			g_cub->map.tmp[i] = '4';
		i++;
	}
	alloc_map(g_cub);
	i = 0;
	j = 0;
	k = 0;
	help_save(g_cub, i, j, k);
	g_cub->map.map[g_cub->map.rows] = NULL;
}

int	save_color(t_cub *g_cub, char *line, int i)
{
	int	color;
	int	j;

	j = 0;
	i++;
	check_color(g_cub, line, i);
	while (ft_isspace(line[i]))
		i++;
	if (line[i] == ',' && ft_isdigit(line[i + 1]))
		exit_game(g_cub, 26);
	check_color(g_cub, line, i);
	color = ft_atoi(&line[i]) * pow(2, 16);
	while (ft_isdigit(line[i]))
		i++;
	while (line[i] == ',' || line[i] == ' ')
	{
		if (line[i] == ',')
			j++;
		i++;
	}
	color = help_color(line, i, color, j);
	return (color);
}

char	*save_texture(char *line, int i)
{
	char	*texture;

	while (ft_isalpha(line[i]))
		i++;
	while (ft_isspace(line[i]))
		i++;
	texture = ft_strtrim(&line[i], " ");
	return (texture);
}
