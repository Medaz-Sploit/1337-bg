/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycast.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/24 15:11:30 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 18:52:44 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	raycast(int col, float rayAngle)
{
	rayDir(rayAngle);
	help_raycast(rayAngle);
	Touch_Horz();
	rayDir(rayAngle);
	utils_raycast(rayAngle);
	Touch_Vert();
	g_cast.horzHitDistance = ternary((g_cast.foundHorzWallHit), \
distanceBetweenPoints(g_cub->rc.pos_x, g_cub->rc.pos_y, g_cast.horzWallHitX, \
g_cast.horzWallHitY), __INT_MAX__);
	g_cast.vertHitDistance = ternary((g_cast.foundVertWallHit), \
distanceBetweenPoints(g_cub->rc.pos_x, g_cub->rc.pos_y, g_cast.vertWallHitX, \
g_cast.vertWallHitY), __INT_MAX__);
	utils_cast(col, rayAngle);
	dda((g_cub->map.height / 2 + g_cast.wallStripHeight / 2), col, \
g_cub->map.height, col);
	g_cub->colo = g_cub->map.ceiling;
	dda(0, col, (g_cub->map.height / 2 - g_cast.wallStripHeight / 2), col);
	ft_empty_trash(rayAngle, col);
}

void	help_raycast(float rayAngle)
{
	g_cast.foundHorzWallHit = false;
	g_cast.horzWallHitX = 0;
	g_cast.horzWallHitY = 0;
	g_cast.yintercept = floor(g_cub->rc.pos_y / TILE_SIZE) * TILE_SIZE;
	g_cast.yintercept += ternary(g_cub->isRayFacingDown, TILE_SIZE, 0);
	g_cast.xintercept = g_cub->rc.pos_x + (g_cast.yintercept - \
g_cub->rc.pos_y) / tan(rayAngle);
	g_cast.ystep = TILE_SIZE;
	g_cast.ystep *= ternary(g_cub->isRayFacingUp, -1, 1);
	g_cast.xstep = TILE_SIZE / tan(rayAngle);
	g_cast.xstep *= ternary((g_cub->isRayFacingLeft && \
g_cast.xstep > 0), -1, 1);
	g_cast.xstep *= ternary((g_cub->isRayFacingRight && \
g_cast.xstep < 0), -1, 1);
	g_cast.nextHorzTouchX = g_cast.xintercept;
	g_cast.nextHorzTouchY = g_cast.yintercept;
}

void	utils_raycast(float rayAngle)
{
	g_cast.foundVertWallHit = false;
	g_cast.vertWallHitX = 0;
	g_cast.vertWallHitY = 0;
	g_cast.xintercept = floor(g_cub->rc.pos_x / TILE_SIZE) * TILE_SIZE;
	g_cast.xintercept += ternary(g_cub->isRayFacingRight, TILE_SIZE, 0);
	g_cast.yintercept = g_cub->rc.pos_y + (g_cast.xintercept - \
g_cub->rc.pos_x) * tan(rayAngle);
	g_cast.xstep = TILE_SIZE;
	g_cast.xstep *= ternary(g_cub->isRayFacingLeft, -1, 1);
	g_cast.ystep = TILE_SIZE * tan(rayAngle);
	g_cast.ystep *= ternary((g_cub->isRayFacingUp && g_cast.ystep > 0), -1, 1);
	g_cast.ystep *= ternary((g_cub->isRayFacingDown && \
g_cast.ystep < 0), -1, 1);
	g_cast.nextVertTouchX = g_cast.xintercept;
	g_cast.nextVertTouchY = g_cast.yintercept;
}

void	utils_cast(int col, float rayAngle)
{
	g_cub->wallHitX = ternary((g_cast.horzHitDistance < \
g_cast.vertHitDistance), g_cast.horzWallHitX, g_cast.vertWallHitX);
	g_cub->wallHitY = ternary((g_cast.horzHitDistance < \
g_cast.vertHitDistance), g_cast.horzWallHitY, g_cast.vertWallHitY);
	g_cub->distance = ternary((g_cast.horzHitDistance < \
g_cast.vertHitDistance), g_cast.horzHitDistance, g_cast.vertHitDistance);
	g_cub->wasHitVertical = (g_cast.vertHitDistance < g_cast.horzHitDistance);
	g_cub->distance *= cos(g_cub->rc.camera_x - rayAngle);
	g_ray_distance[col] = g_cub->distance;
	g_cast.perpDistance = g_cub->distance;
	g_cast.distanceProjPlane = (g_cub->map.height / 2) / tan(FOV_ANGLE / 2);
	g_cast.projectedWallHeight = (TILE_SIZE / g_cast.perpDistance) * \
g_cast.distanceProjPlane;
	g_cast.wallStripHeight = g_cast.projectedWallHeight;
	g_cast.wallTopPixel = (g_cub->map.height / 2) - (g_cast.wallStripHeight / 2);
	g_cast.wallTopPixel = ternary((g_cast.wallTopPixel < 0), 0, \
g_cast.wallTopPixel);
	g_cast.wallBottomPixel = (g_cub->map.height / 2) + (\
g_cast.wallStripHeight / 2);
	g_cast.wallBottomPixel = ternary((g_cast.wallBottomPixel > \
g_cub->map.height), g_cub->map.height, g_cast.wallBottomPixel);
	g_cub->colo = g_cub->map.floor;
}

void	Touch_Horz(void)
{
	while (g_cast.nextHorzTouchX >= 0 && g_cast.nextHorzTouchX < \
g_cub->map.width * TILE_SIZE && g_cast.nextHorzTouchY >= 0 && \
g_cast.nextHorzTouchY < g_cub->map.height * TILE_SIZE)
	{
		if (hasWallAt(g_cast.nextHorzTouchX, \
g_cast.nextHorzTouchY - (ternary(g_cub->isRayFacingUp, 1, 0))))
		{
			g_cast.foundHorzWallHit = true;
			g_cast.horzWallHitX = g_cast.nextHorzTouchX;
			g_cast.horzWallHitY = g_cast.nextHorzTouchY;
			break ;
		}
		else
		{
			g_cast.nextHorzTouchX += g_cast.xstep;
			g_cast.nextHorzTouchY += g_cast.ystep;
		}
	}
}
