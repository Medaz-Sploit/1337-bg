/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tools.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/02 11:42:27 by mazoukni          #+#    #+#             */
/*   Updated: 2021/11/07 14:10:48 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

size_t get_time(void)
{
    struct timeval tv;
    unsigned long int usec;

    gettimeofday(&tv, NULL);
    usec = (1000 * tv.tv_sec) + (tv.tv_usec / 1000);
    return (usec);
}

void    ft_usleep(size_t time)
{
    size_t start;

    start = get_time();
    usleep((time * 1e3) - 20000);
    while (get_time() - start < time)
        ;
}

void    life_span(void)
{
    
}

void    is_dead(void)
{
    
}