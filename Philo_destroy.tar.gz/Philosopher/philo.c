/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/02 09:28:30 by mazoukni          #+#    #+#             */
/*   Updated: 2021/11/07 11:31:33 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void *lifespan_philo(void* philo)
{
    int left_fork;
    int right_fork;
    
    left_fork = ((t_philo*)philo)->id - 1;
    if (((t_philo*)philo)->id - 1 == ((t_philo*)philo)->rules->nbr_philo)
        right_fork = 0;
    else
        right_fork = ((t_philo*)philo)->id;
    if (((t_philo*)philo)->id % 2 == 0)
        usleep(200);
    while (1)
        routine(philo, right_fork, left_fork);
}

void *supervisor(void *rules)
{
    int i;
    size_t current_time;

    i = -1;
    while (++i < ((t_rule*)rules)->nbr_philo)
        pthread_create(&((t_rule*)rules)->philos[i].index, NULL, lifespan_philo, (void*)&((t_rule*)rules)->philos[i]);
    while (1)
    {
        i = -1;
        while (++i < ((t_rule*)rules)->nbr_philo)
        {
            if (((t_rule*)rules)->philos[i].is_eating == 0)
            {
                pthread_mutex_lock(&((t_rule*)rules)->philos[i].eating);
                current_time = get_time();
                if (current_time - ((t_rule*)rules)->philos[i].lastime_eat >= ((t_rule*)rules)->time_to_die)
                {
                     printf("%ld %d died\n", get_time() - ((t_rule*)rules)->time, ((t_rule*)rules)->philos[i].id);
                    return(0);
                }
                pthread_mutex_unlock(&((t_rule*)rules)->philos[i].eating);
            }
        }
    }
    return (NULL);
}

int main(int argc, char **argv)
{
    if (!(argc == 5 || argc == 6))
        return (-1);
    rules.time = get_time();
    ft_init(argc, argv);
    ft_init_philosophers();
    pthread_create(&rules.supervisor, NULL, supervisor, (void *)&rules);
    pthread_join(rules.supervisor, NULL);
    return (0);
}