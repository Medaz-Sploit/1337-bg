/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/07 10:55:30 by mazoukni          #+#    #+#             */
/*   Updated: 2021/11/07 11:27:34 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"


void	routine(t_philo* philo, int right_fork, int left_fork)
{
	eating(philo, right_fork, left_fork);
	sleeping(philo);
}

void	eating(t_philo* philo, int right_fork, int left_fork)
{
	pthread_mutex_lock(&((t_philo*)philo)->forks[left_fork]);
    printf("%ld %d has taken a fork\n",get_time() - ((t_philo*)philo)->rules->time, ((t_philo*)philo)->id);
    pthread_mutex_lock(&((t_philo*)philo)->forks[right_fork]);
    printf("%ld %d has taken a fork\n",get_time() - ((t_philo*)philo)->rules->time ,((t_philo*)philo)->id);
    printf("%ld %d is eating\n",get_time() - ((t_philo*)philo)->rules->time , ((t_philo*)philo)->id);
    pthread_mutex_lock(&((t_philo*)philo)->eating);
     ((t_philo*)philo)->is_eating = 1;
    ((t_philo*)philo)->lastime_eat = get_time();
    ft_usleep(((t_philo*)philo)->rules->time_to_eat);
    ((t_philo*)philo)->is_eating = 0;
    printf("Time is :\t %zu\n", ((t_philo*)philo)->rules->time);
    pthread_mutex_unlock(&((t_philo*)philo)->eating);
    pthread_mutex_unlock(&((t_philo*)philo)->forks[left_fork]);
    pthread_mutex_unlock(&((t_philo*)philo)->forks[right_fork]);
}

void	sleeping(t_philo* philo)
{
	printf("%ld %d is sleeping\n", get_time() - ((t_philo*)philo)->rules->time, ((t_philo*)philo)->id);
    ft_usleep(((t_philo*)philo)->rules->time_to_sleep);
    printf("%ld %d is thinking\n", get_time() - ((t_philo*)philo)->rules->time, ((t_philo*)philo)->id);
}

