/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/27 03:46:50 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/08 01:22:48 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	ft_isspace(int c)
{
	if (c == ' ' || c == '\t' || c == '\v' || \
c == '\f' || c == '\r' || c == '\n')
		return (1);
	return (0);
}

void	buffer_map(char *line)
{
	char	*tmp;

	if (!g_cub->map.tmp)
		g_cub->map.tmp = ft_strdup("");
	else
	{
		tmp = g_cub->map.tmp;
		g_cub->map.tmp = ft_strjoin(g_cub->map.tmp, "\n");
		free(tmp);
	}
	tmp = g_cub->map.tmp;
	g_cub->map.tmp = ft_strjoin(g_cub->map.tmp, line);
	free(tmp);
	g_cub->map.rows++;
}

void	read_map(char *line)
{
	int	i;

	i = 0;
	while (ft_isspace(line[i]))
		i++;
	if ((line[i] == '1' || line[i] == '0') || (line[i] == '\0' && \
g_cub->map.tmp))
		utils_buffer(line, &i);
	else if (g_cub->id.m)
		g_cub->id.m++;
	if (line[i] != ' ' && line[i] != '0' && line[i] != '1' && \
line[i] != 'R' && line[i] != 'N' && line[i] != 'S' && line[i] != 'E' && \
line[i] != 'W' && line[i] != 'F' && line[i] != 'C' && line[i] != '\0')
		exit_game(10);
}

void	read_textures(char *line, int i)
{
	help_texture(line, &i);
	if (line[i] == 'W' && line[i + 1] == 'E' && (ft_isspace(line[i + 2]) || \
line[i + 2] == '\0'))
	{
		if (g_cub->id.we >= 1)
			exit_game(17);
		g_cub->id.we++;
		g_cub->map.west = save_texture(line, i);
	}
	if (line[i] == 'S' && (line[i + 1] == ' ' || line[i + 2] == '\0'))
	{
		if (g_cub->id.s >= 1)
			exit_game(18);
		g_cub->id.s++;
		g_cub->map.sprite = save_texture(line, i);
	}
}

void	read_lin(char *line)
{
	int		i;
	char	**tab;

	i = 0;
	tab = ft_split(line, ' ');
	while (ft_isspace(line[i]))
		i++;
	if (ft_tablen(tab))
	{
		if (!ft_strncmp(tab[0], "R", 1))
			ressolution(&g_cub->map.width, &g_cub->map.height, tab);
	}
	read_textures(line, i);
	utils_line(line, &i);
	read_map(line);
	free_tab(tab);
}
