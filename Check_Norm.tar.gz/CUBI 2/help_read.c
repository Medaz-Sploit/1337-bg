/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_read.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/05 03:29:18 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 03:29:45 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int			read_fil(char **argv, t_cub *g_cub)
{
	int		fd;
	char	*line;

	if ((fd = open(argv[1], O_RDONLY)) < 1)
		exit_game(g_cub, 7);
	while (get_next_line(fd, &line))
	{
		read_lin(g_cub, line);
		free(line);
		line = NULL;
	}
	read_lin(g_cub, line);
	free(line);
	line = NULL;
	close(fd);
	check_file(g_cub);
	free_tab(g_cub->map.map);
	save_map(g_cub);
	check_map(g_cub);
	return (1);
}

size_t	ft_tablen(char **s)
{
	size_t len;

	len = 0;
	if (s)
	{
		while (s[len] != NULL)
			len++;
	}
	return (len);
}