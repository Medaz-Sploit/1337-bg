/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_zero.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/21 04:05:51 by mazoukni          #+#    #+#             */
/*   Updated: 2020/01/21 04:27:35 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int check_zero(char const *format, va_list argp)
{
    int i;

    i = 0;
    if (format[i] == '0' || (format[i] >= '0' && format[i] ''))
    {
        
    }    
}