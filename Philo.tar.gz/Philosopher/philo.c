/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/02 09:28:30 by mazoukni          #+#    #+#             */
/*   Updated: 2021/11/02 13:16:32 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void *lifespan_philo(void* philo)
{
    int left_fork;
    int right_fork;
    
    left_fork = ((t_philo*)philo)->id - 1;
    if (((t_philo*)philo)->id - 1 == ((t_philo*)philo)->rules->nbr_philo)
        right_fork = 0;
    else
        right_fork = ((t_philo*)philo)->id;
    if (((t_philo*)philo)->id % 2 == 0)
        usleep(200);
    while (1)
    {
        pthread_mutex_lock(&((t_philo*)philo)->forks[left_fork]);
        printf("%ld %d has taken a fork\n",get_time() - ((t_philo*)philo)->rules->time, ((t_philo*)philo)->id);
        pthread_mutex_lock(&((t_philo*)philo)->forks[right_fork]);
        printf("%ld %d has taken a fork\n",get_time() - ((t_philo*)philo)->rules->time ,((t_philo*)philo)->id);
        printf("%ld %d is eating\n",get_time() - ((t_philo*)philo)->rules->time , ((t_philo*)philo)->id);
        pthread_mutex_lock(&((t_philo*)philo)->eating);
         ((t_philo*)philo)->is_eating = 1;
        ((t_philo*)philo)->lastime_eat = get_time();
        ft_usleep(((t_philo*)philo)->rules->time_to_eat);
        ((t_philo*)philo)->is_eating = 0;
        pthread_mutex_unlock(&((t_philo*)philo)->eating);
        pthread_mutex_unlock(&((t_philo*)philo)->forks[left_fork]);
        pthread_mutex_unlock(&((t_philo*)philo)->forks[right_fork]);
        printf("%ld %d is sleeping\n", get_time() - ((t_philo*)philo)->rules->time, ((t_philo*)philo)->id);
        ft_usleep(((t_philo*)philo)->rules->time_to_sleep);
        printf("%ld %d is thinking\n", get_time() - ((t_philo*)philo)->rules->time, ((t_philo*)philo)->id);
    }
}

void *supervisor(void *rules)
{
    int i;
    size_t current_time;

    i = -1;
    while (++i < ((t_rule*)rules)->nbr_philo)
        pthread_create(&((t_rule*)rules)->philos[i].index, NULL, lifespan_philo, (void*)&((t_rule*)rules)->philos[i]);
    while (1)
    {
        i = -1;
        while (++i < ((t_rule*)rules)->nbr_philo)
        {
            if (((t_rule*)rules)->philos[i].is_eating == 0)
            {
                pthread_mutex_lock(&((t_rule*)rules)->philos[i].eating);
                current_time = get_time();
                if (current_time - ((t_rule*)rules)->philos[i].lastime_eat >= ((t_rule*)rules)->time_to_die)
                {
                     printf("%ld %d died\n", get_time() - ((t_rule*)rules)->time, ((t_rule*)rules)->philos[i].id);
                    return(0);
                }
                pthread_mutex_unlock(&((t_rule*)rules)->philos[i].eating);
            }
        }
    }
    return (NULL);
}

int main(int argc, char **argv)
{
    int i;

    i = -1;
    t_rule rules;
    rules.time = get_time();
    if (!(argc == 5 || argc == 6))
        return (-1);
    rules.nbr_philo = atoi(argv[1]);
    rules.time_to_die = atoi(argv[2]);
    rules.time_to_eat = atoi(argv[3]);
    rules.time_to_sleep = atoi(argv[4]);
    if (argc == 6)
        rules.nbr_meals = atoi(argv[5]);
    rules.philos = malloc(sizeof(t_philo) * rules.nbr_philo);
    rules.forks = malloc(sizeof(pthread_mutex_t) * rules.nbr_philo);
    while (++i < rules.nbr_philo)
        pthread_mutex_init(&rules.forks[i], NULL);
    pthread_mutex_init(&rules.display, NULL);
    i = -1;
    while (++i < rules.nbr_philo)
    {
        rules.philos[i].forks = rules.forks;
        rules.philos[i].id = i + 1;
        rules.philos[i].meals = 0;
        rules.philos[i].display = &(rules.display);
        rules.philos[i].rules = &rules;
        rules.philos[i].lastime_eat = 0;
        rules.philos[i].is_eating = 0;
        pthread_mutex_init(&(rules.philos[i].eating), NULL);
    }
    pthread_create(&rules.supervisor, NULL, supervisor, (void *)&rules);
    pthread_join(rules.supervisor, NULL);
    return (0);
}