/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/11/02 09:28:34 by mazoukni          #+#    #+#             */
/*   Updated: 2021/11/02 12:11:01 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <pthread.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <strings.h>
# include <stdio.h>
#include <sys/time.h>

struct s_rule;

typedef struct s_philo
{
    pthread_t       index;
    pthread_mutex_t *forks;
    pthread_mutex_t *display;
    pthread_mutex_t eating;
    int             meals;
    int             id;
    size_t          lastime_eat;
    int             is_eating;
    struct  s_rule  *rules;
}              t_philo;

typedef struct s_rule
{
    pthread_t       supervisor;
    pthread_mutex_t *forks;
    t_philo         *philos;
    size_t             time_to_eat;
    size_t             time_to_sleep;
    size_t             time_to_die;
    int             nbr_philo;
    int             nbr_meals;
    pthread_mutex_t display;
    size_t          time;
}               t_rule;

size_t get_time(void);
void    ft_usleep(size_t time);
#endif