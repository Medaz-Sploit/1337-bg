/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_cast.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/04/05 17:48:57 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/05 18:30:00 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

float	normalizeAngle(float angle)
{
	float	angler;

	angler = fmod(angle, (2 * M_PI));
	if (angler < 0)
		angler = (2 * M_PI) + angler;
	return (angler);
}

float	distanceBetweenPoints(float x1, float y1, float x2, float y2)
{
	return (sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)));
}

void	dda(float x0, float y0, float x1, float y1)
{
	g_dda.dx = x1 - x0;
	g_dda.dy = y1 - y0;
	g_dda.steps = ternary((fabs(g_dda.dx) > fabs(g_dda.dy)), \
fabs(g_dda.dx), fabs(g_dda.dy));
	g_dda.Xinc = g_dda.dx / (float) g_dda.steps;
	g_dda.Yinc = g_dda.dy / (float) g_dda.steps;
	g_dda.X = x0;
	g_dda.Y = y0;
	g_dda.i = 0;
	while (g_dda.i < g_dda.steps)
	{
		my_mlx_pixel_put(g_dda.Y, g_dda.X, g_cub->colo);
		g_dda.X += g_dda.Xinc;
		g_dda.Y += g_dda.Yinc;
		g_dda.i++;
	}
}

void	cast(void)
{
	int		i;
	float	rayangle;
	float	angle;

	i = 0;
	rayangle = (FOV_ANGLE / (float)g_cub->map.width);
	angle = (g_cub->rc.camera_x) - (FOV_ANGLE / 2);
	while (i < g_cub->map.width)
	{
		angle = normalizeAngle(angle);
		raycast(i, angle);
		angle += rayangle;
		i++;
	}
}
