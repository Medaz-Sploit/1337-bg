/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   key.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/30 12:57:08 by mazoukni          #+#    #+#             */
/*   Updated: 2021/04/07 22:33:54 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	key_exit(void)
{
	exit_game(0);
	return (0);
}

int	key_release(int keycode)
{
	if (keycode == W)
		g_cub->walkdirection = 0;
	if (keycode == S)
		g_cub->walkdirection = 0;
	if (keycode == D)
		g_cub->turndirection = 0;
	if (keycode == A)
		g_cub->turndirection = 0;
	if (keycode == LEFT)
		g_cub->turndirection = 0;
	if (keycode == RIGHT)
		g_cub->turndirection = 0;
	if (keycode == UP)
		g_cub->walkdirection = 0;
	if (keycode == DOWN)
		g_cub->walkdirection = 0;
	if (keycode == 259 || keycode == 260)
		g_cub->turndirection = 0;
	if (keycode == 259 || keycode == 260)
		g_cub->walkdirection = 0;
	if (keycode == ESC || keycode == 12)
		key_exit();
	return (0);
}

int	key_press(int keycode)
{
	if (keycode == W)
		g_cub->walkdirection = 1;
	if (keycode == S)
		g_cub->walkdirection = -1;
	if (keycode == D)
		g_cub->turndirection = 1;
	if (keycode == A)
		g_cub->turndirection = -1;
	if (keycode == LEFT)
		g_cub->turndirection = -1;
	if (keycode == RIGHT)
		g_cub->turndirection = 1;
	if (keycode == UP)
		g_cub->walkdirection = 1;
	if (keycode == DOWN)
		g_cub->walkdirection = -1;
	return (0);
}
